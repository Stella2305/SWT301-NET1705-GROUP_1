export interface VenueCreateRequest {
  fileImage: any
  venueName: string
  venueDescription: string
  location: string
  capacity: number
}
