export interface SlotCreateRequest {
  timeStart: string
  timeEnd: string
}
