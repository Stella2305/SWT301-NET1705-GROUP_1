export interface ServiceCreateRequest {
  fileImage: any
  serviceName: string
  serviceDescription: string
  pricing: string
}
