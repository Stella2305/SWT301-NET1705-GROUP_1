import { SlotInVenueDataResponse } from './slot.response'

export interface PartyDatedDataResponse {
  id: number
  date: string
  active: boolean
  slotInVenue: SlotInVenueDataResponse
}
