import React from 'react'

const Index = () => {
  return <div></div>
}

export default Index
