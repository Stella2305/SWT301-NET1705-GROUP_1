export const headerFormData = {
  'Content-Type': 'multipart/form-data'
}
