export const imageUrlIfUndefined = "https://bitsofco.de/img/Qo5mfYDE5v-350.png";
