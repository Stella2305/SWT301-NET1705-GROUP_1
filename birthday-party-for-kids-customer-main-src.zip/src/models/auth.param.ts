export interface REGISTER_PARAM {
  username: string | null;
  password: string | null;
  fullName: string | null;
  email: string | null;
  phone: string | null;
}
export interface LOGIN_PARAM {
  username: string | null;
  password: string | null;
}
