import React from 'react'

function BookingHistory() {
  return (
    <div>booking-history</div>
  )
}

export default BookingHistory